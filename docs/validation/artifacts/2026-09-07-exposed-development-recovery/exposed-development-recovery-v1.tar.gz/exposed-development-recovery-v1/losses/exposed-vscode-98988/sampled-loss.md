# Original unrecoverable-head loss

Source: microsoft/vscode #98988. This original reconstruction loss is preserved separately from the twelve recovered opportunity drafts. The exact reviewed head was unavailable during the original reconstruction; rebased corroboration must not replace it. See [original record](../../evidence/reconstructions/main-development-second.md) and [independent check](../../evidence/reconstructions/independent-development-check-second.md).

Later scratch-storage disappearance is a separate recovery limitation, not a new case rejection. No slot substitution, human decision, admission, or runtime proof is created here.

Human decision:
Reason:
