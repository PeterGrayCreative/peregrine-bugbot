import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const out=path.dirname(fileURLToPath(import.meta.url));
const source='/Users/petergray/Documents/peregrine-bugbot/.worktrees/ts-js-evidence-r2/docs/validation/artifacts/2026-09-05-r2-candidate-inventory';
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const originals=['development-reconstruction-bundle-v1.json','development-reconstruction-bundle-second-v1.json'];
const expected=new Map();
for(const manifest of originals){
  const b=fs.readFileSync(path.join(source,manifest));
  expected.set(manifest,{path:manifest,bytes:b.length,sha256:digest(b)});
  for(const entry of JSON.parse(b).files){
    const old=expected.get(entry.path);
    if(old&&(old.sha256!==entry.sha256||old.bytes!==entry.bytes))throw Error('Conflicting source binding');
    expected.set(entry.path,entry);
  }
}
if(fs.existsSync(path.join(out,'evidence')))throw Error('Refusing to overwrite evidence');
for(const entry of expected.values()){
  if(path.isAbsolute(entry.path)||entry.path.split('/').includes('..'))throw Error('Unsafe source path');
  const from=path.join(source,entry.path);
  if(!fs.lstatSync(from).isFile())throw Error('Nonregular source');
  const b=fs.readFileSync(from);
  if(b.length!==entry.bytes||digest(b)!==entry.sha256)throw Error('Original binding mismatch: '+entry.path);
  const to=path.join(out,'evidence',entry.path);
  fs.mkdirSync(path.dirname(to),{recursive:true});
  fs.copyFileSync(from,to,fs.constants.COPYFILE_EXCL);
  if(digest(fs.readFileSync(to))!==entry.sha256)throw Error('Copy mismatch');
}
const licenses=[];
for(const entry of expected.values()){
  let obj;try{obj=JSON.parse(fs.readFileSync(path.join(source,entry.path),'utf8'));}catch{continue;}
  const payload=obj?.content&&typeof obj.content==='object'?obj.content:obj;
  if(payload?.encoding!=='base64'||typeof payload.content!=='string'||!/licen[cs]e/i.test(payload.name??payload.path??''))continue;
  const b=Buffer.from(payload.content,'base64');
  const gitSha=crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
  if(payload.sha!==gitSha||payload.size!==b.length)throw Error('License Git blob verification failed: '+entry.path);
  const target='decoded-licenses/'+gitSha+'.txt';
  fs.mkdirSync(path.join(out,'decoded-licenses'),{recursive:true});
  if(!fs.existsSync(path.join(out,target)))fs.writeFileSync(path.join(out,target),b,{flag:'wx'});
  licenses.push({sourcePath:'evidence/'+entry.path,sourceSha256:entry.sha256,historicalPath:payload.path,gitBlobSha1:gitSha,decodedPath:target,decodedBytes:b.length,decodedSha256:digest(b),method:'base64; verified Git SHA1 blob identity and API byte size; original response authenticated by tracked bundle manifest'});
}
fs.writeFileSync(path.join(out,'license-decode-manifest.json'),JSON.stringify({version:1,licenses,limitations:'Applicability to each reviewed head must follow the original report and request receipt; decode does not authenticate remote authorship or restore repository history.'},null,2)+'\n',{flag:'wx'});
function filesAt(dir,prefix=''){
  return fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en')).flatMap(e=>{
    if(e.isSymbolicLink())throw Error('Symlink in recovered tree');
    const rel=prefix+e.name;
    return e.isDirectory()?filesAt(path.join(dir,e.name),rel+'/'):[rel];
  });
}
const files=filesAt(out).filter(p=>p!=='recovery-manifest.json').map(p=>{
  const b=fs.readFileSync(path.join(out,p));return {path:p,bytes:b.length,sha256:digest(b)};
});
const manifest={version:1,sourceCommit:'afb1d2c',status:'recovery-drafts-unresolved-not-final-packet',cards:12,defectHypotheses:7,scopedComparisonHypotheses:5,originalUnrecoverableLeadLosses:1,humanDecisions:0,admissions:0,sourceCopies:expected.size,licenseDecodes:licenses.length,files};
fs.writeFileSync(path.join(out,'recovery-manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
for(const entry of files){const b=fs.readFileSync(path.join(out,entry.path));if(b.length!==entry.bytes||digest(b)!==entry.sha256)throw Error('Final verification mismatch');}
const actual=filesAt(out).filter(p=>p!=='recovery-manifest.json');
if(actual.length!==files.length)throw Error('Complete file-list mismatch');
console.log(JSON.stringify({sourceCopies:expected.size,verifiedFiles:files.length,licenseDecodes:licenses.length,uniqueLicenseFiles:new Set(licenses.map(x=>x.decodedPath)).size,manifestSha256:digest(fs.readFileSync(path.join(out,'recovery-manifest.json')))},null,2));
