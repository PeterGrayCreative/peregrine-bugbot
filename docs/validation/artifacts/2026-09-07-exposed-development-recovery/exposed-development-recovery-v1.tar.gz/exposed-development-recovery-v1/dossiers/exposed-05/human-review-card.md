# exposed-05: draft human review card

Proposed class: defect-bearing. Preparation status: draft / unresolved. Human decision: blank. This is not a review-ready final packet.

Source: [vercel/next.js #7363](https://github.com/vercel/next.js/pull/7363). Exposure: existing visible development. Source-family group: `next-7363`. The preserved [exposure register](../../evidence/development-exposure-v1.json) identifies the original lead; it is not a new inventory slot.

[Original proof and exact historical identities](../../evidence/reconstructions/beta-development.md) retain dates, base/head/tree identities, contemporaneous observations, static causal trace, repair relations or their absence, proposed scope, contrary evidence, severity limits, and original provenance. Read with all three independent corrections: [first](../../evidence/reconstructions/independent-development-check.md), [remaining first batch](../../evidence/reconstructions/independent-development-check-remaining.md), [second batch](../../evidence/reconstructions/independent-development-check-second.md). These are AI evidence checks, not human confirmations.

[Canonical review diff](../../evidence/reconstruction-sources/beta/diffs/next-7363-review.diff) is preserved byte-for-byte. Exact copied file sizes and hashes are bound in [recovery manifest](../../recovery-manifest.json). Original raw responses, receipts, and repair diffs remain under the linked original evidence archive. The [license decode manifest](../../license-decode-manifest.json) maps authenticated readable license bytes to their original response objects; a decoded license is not assumed to apply to a particular head without the original report's identity binding.

Current gap: source clones and replay archives are absent. No historical tree, ancestry, runtime reproduction, or materializer readiness has been re-established. Original absolute scratch references remain unresolved; this recovery does not establish full source/proof reference closure. Preparation remains unresolved until exact per-case evidence and license applicability are reconciled for the consolidated packet.

Case-specific limitation: Static MIME trace only; no local historical execution or new runtime proof.

Human controls for the future consolidated packet (leave all blank here):

- Decision (approve / reject / unresolved):
- Required reason:
- Optional correction:
- Acknowledged dossier hash:
- Human identity:
- Decision date:

No decision is inferred from this draft, missing source bytes, or the retained AI reports. A class/scope correction needs a new append-only dossier version. No admissions or partition assignments.

