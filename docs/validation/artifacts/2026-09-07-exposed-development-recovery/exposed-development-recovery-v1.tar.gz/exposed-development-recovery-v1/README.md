# Exposed development evidence recovery v1

Recovered 2026-09-07 from tracked evidence at implementation commit afb1d2c. This is persistent recovery preparation, not the consolidated human packet or a request to review a partial batch.

Twelve draft opportunity cards preserve seven defect and five scoped-comparison hypotheses. They are all unresolved preparation: exact source repositories and replay archives are unavailable; original reports retain static proof and limitations. No human decision, independent-human confirmation, admission, or partition is created. The two NestJS #383 heads share one PR/source family. The original VS Code #98988 unrecoverable-head loss is retained separately and is not caused by the later scratch-storage loss.

`evidence/` preserves exact original bytes from both development manifests. `decoded-licenses/` contains only authenticated derived bytes with decode provenance. `recovery-manifest.json` binds every recovered and newly authored file other than itself. Its digest is recorded in the implementation aggregate report. Review cards link to original reports rather than superseding their conclusions or independent corrections. Embedded original scratch paths remain unresolved; preserving source bytes does not repair those links or establish reference closure.

AI preparation identity: `codex-task:/root/recovery_evidence_inventory`. All material was already exposed development evidence. This directory does not provide protected-selection access control. Human decision fields remain blank for a future immutable consolidated packet and separate response folder.
